using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Linq;
using Crestron;
using Crestron.Logos.SplusLibrary;
using Crestron.Logos.SplusObjects;
using Crestron.SimplSharp;

namespace UserModule_PJLINK
{
    public class UserModuleClass_PJLINK : SplusObject
    {
        static CCriticalSection g_criticalSection = new CCriticalSection();
        
        
        
        
        
        
        
        Crestron.Logos.SplusObjects.StringInput COMMAND__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput DOCLIENTCONNECTED;
        Crestron.Logos.SplusObjects.DigitalOutput LAMP1ON__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput LAMP2ON__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput FANWARNING__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput FANERROR__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput LAMPWARNING__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput LAMPERROR__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput TEMPERATUREWARNING__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput TEMPERATUREERROR__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput COVEROPENWARNING__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput COVEROPENERROR__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput FILTERWARNING__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput FILTERERROR__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput OTHERWARNING__DOLLAR__;
        Crestron.Logos.SplusObjects.DigitalOutput OTHERERROR__DOLLAR__;
        Crestron.Logos.SplusObjects.AnalogOutput AOCLIENTSTATUS;
        Crestron.Logos.SplusObjects.AnalogOutput INPUTFEEDBACK__DOLLAR__;
        Crestron.Logos.SplusObjects.AnalogOutput LAMP1HOURS__DOLLAR__;
        Crestron.Logos.SplusObjects.AnalogOutput LAMP2HOURS__DOLLAR__;
        Crestron.Logos.SplusObjects.StringOutput SENDTOSIMPLEWINDOWS__DOLLAR__;
        SplusTcpClient MYCLIENT;
        UShortParameter PROJECTOR_TCPIP_PORTNUMBER;
        StringParameter PROJECTOR_IP_ADDRESS;
        StringParameter PJLINKPASSWORD;
        CrestronString SCLIENTRX__DOLLAR__;
        CrestronString COMMANDVALUE__DOLLAR__;
        CrestronString REPLYERR__DOLLAR__;
        CrestronString REPLYVALUE__DOLLAR__;
        CrestronString RNDM__DOLLAR__;
        CrestronString COMMANDLIST;
        CrestronString RXCOMMAND;
        CrestronString NEXTCOMMAND;
        CrestronString REPLYOK;
        ushort [] HEX_TAB;
        ushort RXVALUE = 0;
        ushort ISTARTCLIENT = 0;
        ushort RXOK = 0;
        ushort PROCESSINGCOMMANDS = 0;
        ushort REPLYACK = 0;
        ushort HELPRX = 0;
        ushort QUERY = 0;
        int CHRSZ = 0;
        int [] BIN;
        int [] BINARRAY;
        private CrestronString BINL2HEX (  SplusExecutionContext __context__ ) 
            { 
            ushort I = 0;
            
            CrestronString STR;
            STR  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 128, this );
            
            
            __context__.SourceCodeLine = 135;
            I = (ushort) ( 0 ) ; 
            __context__.SourceCodeLine = 136;
            while ( Functions.TestForTrue  ( ( Functions.BoolToInt ( I < 16 ))  ) ) 
                { 
                __context__.SourceCodeLine = 138;
                STR  .UpdateValue ( STR + Functions.Chr (  (int) ( HEX_TAB[ ((BINARRAY[ (I >> 2) ] >> ((Mod( I , 4 ) * 8) + 4)) & 15) ] ) ) + Functions.Chr (  (int) ( HEX_TAB[ ((BINARRAY[ (I >> 2) ] >> (Mod( I , 4 ) * 8)) & 15) ] ) )  ) ; 
                __context__.SourceCodeLine = 139;
                I = (ushort) ( (I + 1) ) ; 
                __context__.SourceCodeLine = 136;
                } 
            
            __context__.SourceCodeLine = 142;
            return ( STR ) ; 
            
            }
            
        private int SAFE_ADD (  SplusExecutionContext __context__, int X , int Y ) 
            { 
            int LSW = 0;
            int MSW = 0;
            
            
            __context__.SourceCodeLine = 148;
            LSW = (int) ( ((X & 65535) + (Y & 65535)) ) ; 
            __context__.SourceCodeLine = 149;
            MSW = (int) ( (((X >> 16) + (Y >> 16)) + (LSW >> 16)) ) ; 
            __context__.SourceCodeLine = 151;
            return (int)( ((MSW << 16) | (LSW & 65535))) ; 
            
            }
            
        private int BIT_ROL (  SplusExecutionContext __context__, int NUM , short CNT ) 
            { 
            
            __context__.SourceCodeLine = 156;
            return (int)( (Functions.RotateLeftLong( (uint)( NUM ) , (uint)( CNT ) ) | Functions.RotateRightLong( (uint)( NUM ) , (uint)( (32 - CNT) ) ))) ; 
            
            }
            
        private int MD5_CMN (  SplusExecutionContext __context__, int Q , int A , int B , int X , short S , int T ) 
            { 
            
            __context__.SourceCodeLine = 161;
            return (int)( SAFE_ADD( __context__ , (int)( BIT_ROL( __context__ , (int)( SAFE_ADD( __context__ , (int)( SAFE_ADD( __context__ , (int)( A ) , (int)( Q ) ) ) , (int)( SAFE_ADD( __context__ , (int)( X ) , (int)( T ) ) ) ) ) , (short)( S ) ) ) , (int)( B ) )) ; 
            
            }
            
        private int MD5_FF (  SplusExecutionContext __context__, int A , int B , int C , int D , int X , short S , int T ) 
            { 
            
            __context__.SourceCodeLine = 166;
            return (int)( MD5_CMN( __context__ , (int)( ((B & C) | (Functions.OnesComplement( B ) & D)) ) , (int)( A ) , (int)( B ) , (int)( X ) , (short)( S ) , (int)( T ) )) ; 
            
            }
            
        private int MD5_GG (  SplusExecutionContext __context__, int A , int B , int C , int D , int X , short S , int T ) 
            { 
            
            __context__.SourceCodeLine = 171;
            return (int)( MD5_CMN( __context__ , (int)( ((B & D) | (C & Functions.OnesComplement( D ))) ) , (int)( A ) , (int)( B ) , (int)( X ) , (short)( S ) , (int)( T ) )) ; 
            
            }
            
        private int MD5_HH (  SplusExecutionContext __context__, int A , int B , int C , int D , int X , short S , int T ) 
            { 
            
            __context__.SourceCodeLine = 176;
            return (int)( MD5_CMN( __context__ , (int)( ((B ^ C) ^ D) ) , (int)( A ) , (int)( B ) , (int)( X ) , (short)( S ) , (int)( T ) )) ; 
            
            }
            
        private int MD5_II (  SplusExecutionContext __context__, int A , int B , int C , int D , int X , short S , int T ) 
            { 
            
            __context__.SourceCodeLine = 181;
            return (int)( MD5_CMN( __context__ , (int)( (C ^ (B | Functions.OnesComplement( D ))) ) , (int)( A ) , (int)( B ) , (int)( X ) , (short)( S ) , (int)( T ) )) ; 
            
            }
            
        private CrestronString CORE_MD5 (  SplusExecutionContext __context__, ushort LENGTH ) 
            { 
            ushort I = 0;
            
            int A = 0;
            int B = 0;
            int C = 0;
            int D = 0;
            int OLDA = 0;
            int OLDB = 0;
            int OLDC = 0;
            int OLDD = 0;
            
            
            __context__.SourceCodeLine = 188;
            BIN [ (LENGTH >> 5)] = (int) ( (BIN[ (LENGTH >> 5) ] | (128 << Mod( LENGTH , 32 ))) ) ; 
            __context__.SourceCodeLine = 189;
            BIN [ (Crestron.Logos.SplusLibrary.Functions.RotateLeftLong( (uint)((LENGTH + 64) >> 9) , 4 ) + 14)] = (int) ( LENGTH ) ; 
            __context__.SourceCodeLine = 191;
            A = (int) ( 1732584193 ) ; 
            __context__.SourceCodeLine = 192;
            B = (int) ( Functions.ToSignedLongInteger( -( 271733879 ) ) ) ; 
            __context__.SourceCodeLine = 193;
            C = (int) ( Functions.ToSignedLongInteger( -( 1732584194 ) ) ) ; 
            __context__.SourceCodeLine = 194;
            D = (int) ( 271733878 ) ; 
            __context__.SourceCodeLine = 196;
            I = (ushort) ( 0 ) ; 
            __context__.SourceCodeLine = 197;
            while ( Functions.TestForTrue  ( ( Functions.BoolToInt ( I < 15 ))  ) ) 
                { 
                __context__.SourceCodeLine = 199;
                OLDA = (int) ( A ) ; 
                __context__.SourceCodeLine = 200;
                OLDB = (int) ( B ) ; 
                __context__.SourceCodeLine = 201;
                OLDC = (int) ( C ) ; 
                __context__.SourceCodeLine = 202;
                OLDD = (int) ( D ) ; 
                __context__.SourceCodeLine = 204;
                A = (int) ( MD5_FF( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 0) ] ) , (short)( 7 ) , (int)( Functions.ToSignedLongInteger( -( 680876936 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 205;
                D = (int) ( MD5_FF( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 1) ] ) , (short)( 12 ) , (int)( Functions.ToSignedLongInteger( -( 389564586 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 206;
                C = (int) ( MD5_FF( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 2) ] ) , (short)( 17 ) , (int)( 606105819 ) ) ) ; 
                __context__.SourceCodeLine = 207;
                B = (int) ( MD5_FF( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 3) ] ) , (short)( 22 ) , (int)( Functions.ToSignedLongInteger( -( 1044525330 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 208;
                A = (int) ( MD5_FF( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 4) ] ) , (short)( 7 ) , (int)( Functions.ToSignedLongInteger( -( 176418897 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 209;
                D = (int) ( MD5_FF( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 5) ] ) , (short)( 12 ) , (int)( 1200080426 ) ) ) ; 
                __context__.SourceCodeLine = 210;
                C = (int) ( MD5_FF( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 6) ] ) , (short)( 17 ) , (int)( Functions.ToSignedLongInteger( -( 1473231341 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 211;
                B = (int) ( MD5_FF( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 7) ] ) , (short)( 22 ) , (int)( Functions.ToSignedLongInteger( -( 45705983 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 212;
                A = (int) ( MD5_FF( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 8) ] ) , (short)( 7 ) , (int)( 1770035416 ) ) ) ; 
                __context__.SourceCodeLine = 213;
                D = (int) ( MD5_FF( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 9) ] ) , (short)( 12 ) , (int)( Functions.ToSignedLongInteger( -( 1958414417 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 214;
                C = (int) ( MD5_FF( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 10) ] ) , (short)( 17 ) , (int)( Functions.ToSignedLongInteger( -( 42063 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 215;
                B = (int) ( MD5_FF( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 11) ] ) , (short)( 22 ) , (int)( Functions.ToSignedLongInteger( -( 1990404162 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 216;
                A = (int) ( MD5_FF( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 12) ] ) , (short)( 7 ) , (int)( 1804603682 ) ) ) ; 
                __context__.SourceCodeLine = 217;
                D = (int) ( MD5_FF( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 13) ] ) , (short)( 12 ) , (int)( Functions.ToSignedLongInteger( -( 40341101 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 218;
                C = (int) ( MD5_FF( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 14) ] ) , (short)( 17 ) , (int)( Functions.ToSignedLongInteger( -( 1502002290 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 219;
                B = (int) ( MD5_FF( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 15) ] ) , (short)( 22 ) , (int)( 1236535329 ) ) ) ; 
                __context__.SourceCodeLine = 221;
                A = (int) ( MD5_GG( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 1) ] ) , (short)( 5 ) , (int)( Functions.ToSignedLongInteger( -( 165796510 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 222;
                D = (int) ( MD5_GG( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 6) ] ) , (short)( 9 ) , (int)( Functions.ToSignedLongInteger( -( 1069501632 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 223;
                C = (int) ( MD5_GG( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 11) ] ) , (short)( 14 ) , (int)( 643717713 ) ) ) ; 
                __context__.SourceCodeLine = 224;
                B = (int) ( MD5_GG( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 0) ] ) , (short)( 20 ) , (int)( Functions.ToSignedLongInteger( -( 373897302 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 225;
                A = (int) ( MD5_GG( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 5) ] ) , (short)( 5 ) , (int)( Functions.ToSignedLongInteger( -( 701558691 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 226;
                D = (int) ( MD5_GG( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 10) ] ) , (short)( 9 ) , (int)( 38016083 ) ) ) ; 
                __context__.SourceCodeLine = 227;
                C = (int) ( MD5_GG( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 15) ] ) , (short)( 14 ) , (int)( Functions.ToSignedLongInteger( -( 660478335 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 228;
                B = (int) ( MD5_GG( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 4) ] ) , (short)( 20 ) , (int)( Functions.ToSignedLongInteger( -( 405537848 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 229;
                A = (int) ( MD5_GG( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 9) ] ) , (short)( 5 ) , (int)( 568446438 ) ) ) ; 
                __context__.SourceCodeLine = 230;
                D = (int) ( MD5_GG( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 14) ] ) , (short)( 9 ) , (int)( Functions.ToSignedLongInteger( -( 1019803690 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 231;
                C = (int) ( MD5_GG( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 3) ] ) , (short)( 14 ) , (int)( Functions.ToSignedLongInteger( -( 187363961 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 232;
                B = (int) ( MD5_GG( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 8) ] ) , (short)( 20 ) , (int)( 1163531501 ) ) ) ; 
                __context__.SourceCodeLine = 233;
                A = (int) ( MD5_GG( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 13) ] ) , (short)( 5 ) , (int)( Functions.ToSignedLongInteger( -( 1444681467 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 234;
                D = (int) ( MD5_GG( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 2) ] ) , (short)( 9 ) , (int)( Functions.ToSignedLongInteger( -( 51403784 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 235;
                C = (int) ( MD5_GG( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 7) ] ) , (short)( 14 ) , (int)( 1735328473 ) ) ) ; 
                __context__.SourceCodeLine = 236;
                B = (int) ( MD5_GG( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 12) ] ) , (short)( 20 ) , (int)( Functions.ToSignedLongInteger( -( 1926607734 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 238;
                A = (int) ( MD5_HH( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 5) ] ) , (short)( 4 ) , (int)( Functions.ToSignedLongInteger( -( 378558 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 239;
                D = (int) ( MD5_HH( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 8) ] ) , (short)( 11 ) , (int)( Functions.ToSignedLongInteger( -( 2022574463 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 240;
                C = (int) ( MD5_HH( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 11) ] ) , (short)( 16 ) , (int)( 1839030562 ) ) ) ; 
                __context__.SourceCodeLine = 241;
                B = (int) ( MD5_HH( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 14) ] ) , (short)( 23 ) , (int)( Functions.ToSignedLongInteger( -( 35309556 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 242;
                A = (int) ( MD5_HH( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 1) ] ) , (short)( 4 ) , (int)( Functions.ToSignedLongInteger( -( 1530992060 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 243;
                D = (int) ( MD5_HH( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 4) ] ) , (short)( 11 ) , (int)( 1272893353 ) ) ) ; 
                __context__.SourceCodeLine = 244;
                C = (int) ( MD5_HH( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 7) ] ) , (short)( 16 ) , (int)( Functions.ToSignedLongInteger( -( 155497632 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 245;
                B = (int) ( MD5_HH( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 10) ] ) , (short)( 23 ) , (int)( Functions.ToSignedLongInteger( -( 1094730640 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 246;
                A = (int) ( MD5_HH( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 13) ] ) , (short)( 4 ) , (int)( 681279174 ) ) ) ; 
                __context__.SourceCodeLine = 247;
                D = (int) ( MD5_HH( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 0) ] ) , (short)( 11 ) , (int)( Functions.ToSignedLongInteger( -( 358537222 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 248;
                C = (int) ( MD5_HH( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 3) ] ) , (short)( 16 ) , (int)( Functions.ToSignedLongInteger( -( 722521979 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 249;
                B = (int) ( MD5_HH( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 6) ] ) , (short)( 23 ) , (int)( 76029189 ) ) ) ; 
                __context__.SourceCodeLine = 250;
                A = (int) ( MD5_HH( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 9) ] ) , (short)( 4 ) , (int)( Functions.ToSignedLongInteger( -( 640364487 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 251;
                D = (int) ( MD5_HH( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 12) ] ) , (short)( 11 ) , (int)( Functions.ToSignedLongInteger( -( 421815835 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 252;
                C = (int) ( MD5_HH( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 15) ] ) , (short)( 16 ) , (int)( 530742520 ) ) ) ; 
                __context__.SourceCodeLine = 253;
                B = (int) ( MD5_HH( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 2) ] ) , (short)( 23 ) , (int)( Functions.ToSignedLongInteger( -( 995338651 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 255;
                A = (int) ( MD5_II( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 0) ] ) , (short)( 6 ) , (int)( Functions.ToSignedLongInteger( -( 198630844 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 256;
                D = (int) ( MD5_II( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 7) ] ) , (short)( 10 ) , (int)( 1126891415 ) ) ) ; 
                __context__.SourceCodeLine = 257;
                C = (int) ( MD5_II( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 14) ] ) , (short)( 15 ) , (int)( Functions.ToSignedLongInteger( -( 1416354905 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 258;
                B = (int) ( MD5_II( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 5) ] ) , (short)( 21 ) , (int)( Functions.ToSignedLongInteger( -( 57434055 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 259;
                A = (int) ( MD5_II( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 12) ] ) , (short)( 6 ) , (int)( 1700485571 ) ) ) ; 
                __context__.SourceCodeLine = 260;
                D = (int) ( MD5_II( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 3) ] ) , (short)( 10 ) , (int)( Functions.ToSignedLongInteger( -( 1894986606 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 261;
                C = (int) ( MD5_II( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 10) ] ) , (short)( 15 ) , (int)( Functions.ToSignedLongInteger( -( 1051523 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 262;
                B = (int) ( MD5_II( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 1) ] ) , (short)( 21 ) , (int)( Functions.ToSignedLongInteger( -( 2054922799 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 263;
                A = (int) ( MD5_II( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 8) ] ) , (short)( 6 ) , (int)( 1873313359 ) ) ) ; 
                __context__.SourceCodeLine = 264;
                D = (int) ( MD5_II( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 15) ] ) , (short)( 10 ) , (int)( Functions.ToSignedLongInteger( -( 30611744 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 265;
                C = (int) ( MD5_II( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 06) ] ) , (short)( 15 ) , (int)( Functions.ToSignedLongInteger( -( 1560198380 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 266;
                B = (int) ( MD5_II( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 13) ] ) , (short)( 21 ) , (int)( 1309151649 ) ) ) ; 
                __context__.SourceCodeLine = 267;
                A = (int) ( MD5_II( __context__ , (int)( A ) , (int)( B ) , (int)( C ) , (int)( D ) , (int)( BIN[ (I + 4) ] ) , (short)( 6 ) , (int)( Functions.ToSignedLongInteger( -( 145523070 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 268;
                D = (int) ( MD5_II( __context__ , (int)( D ) , (int)( A ) , (int)( B ) , (int)( C ) , (int)( BIN[ (I + 11) ] ) , (short)( 10 ) , (int)( Functions.ToSignedLongInteger( -( 1120210379 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 269;
                C = (int) ( MD5_II( __context__ , (int)( C ) , (int)( D ) , (int)( A ) , (int)( B ) , (int)( BIN[ (I + 2) ] ) , (short)( 15 ) , (int)( 718787259 ) ) ) ; 
                __context__.SourceCodeLine = 270;
                B = (int) ( MD5_II( __context__ , (int)( B ) , (int)( C ) , (int)( D ) , (int)( A ) , (int)( BIN[ (I + 9) ] ) , (short)( 21 ) , (int)( Functions.ToSignedLongInteger( -( 343485551 ) ) ) ) ) ; 
                __context__.SourceCodeLine = 272;
                A = (int) ( SAFE_ADD( __context__ , (int)( A ) , (int)( OLDA ) ) ) ; 
                __context__.SourceCodeLine = 273;
                B = (int) ( SAFE_ADD( __context__ , (int)( B ) , (int)( OLDB ) ) ) ; 
                __context__.SourceCodeLine = 274;
                C = (int) ( SAFE_ADD( __context__ , (int)( C ) , (int)( OLDC ) ) ) ; 
                __context__.SourceCodeLine = 275;
                D = (int) ( SAFE_ADD( __context__ , (int)( D ) , (int)( OLDD ) ) ) ; 
                __context__.SourceCodeLine = 277;
                I = (ushort) ( (I + 16) ) ; 
                __context__.SourceCodeLine = 197;
                } 
            
            __context__.SourceCodeLine = 279;
            BINARRAY [ 0] = (int) ( A ) ; 
            __context__.SourceCodeLine = 280;
            BINARRAY [ 1] = (int) ( B ) ; 
            __context__.SourceCodeLine = 281;
            BINARRAY [ 2] = (int) ( C ) ; 
            __context__.SourceCodeLine = 282;
            BINARRAY [ 3] = (int) ( D ) ; 
            
            return ""; // default return value (none specified in module)
            }
            
        private void STR2BINL (  SplusExecutionContext __context__, CrestronString STR ) 
            { 
            ushort I = 0;
            ushort MASK = 0;
            
            int ONE = 0;
            int TEMP__DOLLAR__ = 0;
            
            
            __context__.SourceCodeLine = 290;
            ONE = (int) ( 1 ) ; 
            __context__.SourceCodeLine = 291;
            MASK = (ushort) ( ((ONE << CHRSZ) - 1) ) ; 
            __context__.SourceCodeLine = 292;
            I = (ushort) ( 0 ) ; 
            __context__.SourceCodeLine = 293;
            while ( Functions.TestForTrue  ( ( Functions.BoolToInt ( I < (Functions.Length( STR ) * CHRSZ) ))  ) ) 
                { 
                __context__.SourceCodeLine = 295;
                BIN [ (I >> 5)] = (int) ( (BIN[ (I >> 5) ] | ((Byte( STR , (int)( ((I / 8) + 1) ) ) & MASK) << Mod( I , 32 ))) ) ; 
                __context__.SourceCodeLine = 296;
                I = (ushort) ( (I + 8) ) ; 
                __context__.SourceCodeLine = 293;
                } 
            
            
            }
            
        private CrestronString HEX_MD5 (  SplusExecutionContext __context__, CrestronString S ) 
            { 
            
            __context__.SourceCodeLine = 302;
            Functions.SetArray (  ref BIN , (int)0) ; 
            __context__.SourceCodeLine = 303;
            STR2BINL (  __context__ , S) ; 
            __context__.SourceCodeLine = 304;
            CORE_MD5 (  __context__ , (ushort)( (Functions.Length( S ) * Functions.LowWord( (uint)( CHRSZ ) )) )) ; 
            __context__.SourceCodeLine = 305;
            return ( BINL2HEX (  __context__  ) ) ; 
            
            }
            
        private ushort FSTARTCLIENT (  SplusExecutionContext __context__ ) 
            { 
            short ISTATUS = 0;
            
            
            __context__.SourceCodeLine = 315;
            ISTARTCLIENT = (ushort) ( 1 ) ; 
            __context__.SourceCodeLine = 316;
            ISTATUS = (short) ( Functions.SocketConnectClient( MYCLIENT , PROJECTOR_IP_ADDRESS  , (ushort)( PROJECTOR_TCPIP_PORTNUMBER  .Value ) , (ushort)( 0 ) ) ) ; 
            __context__.SourceCodeLine = 317;
            return (ushort)( ISTATUS) ; 
            
            }
            
        private ushort FSTOPCLIENT (  SplusExecutionContext __context__ ) 
            { 
            short ISTATUS = 0;
            
            
            __context__.SourceCodeLine = 324;
            Functions.Delay (  (int) ( 5 ) ) ; 
            __context__.SourceCodeLine = 325;
            ISTARTCLIENT = (ushort) ( 0 ) ; 
            __context__.SourceCodeLine = 326;
            ISTATUS = (short) ( Functions.SocketDisconnectClient( MYCLIENT ) ) ; 
            __context__.SourceCodeLine = 327;
            return (ushort)( ISTATUS) ; 
            
            }
            
        private ushort FCLIENTTX (  SplusExecutionContext __context__, CrestronString CLIENTTX__DOLLAR__ ) 
            { 
            short ISTATUS = 0;
            
            
            __context__.SourceCodeLine = 334;
            ISTATUS = (short) ( Functions.SocketSend( MYCLIENT , CLIENTTX__DOLLAR__ ) ) ; 
            __context__.SourceCodeLine = 335;
            return (ushort)( ISTATUS) ; 
            
            }
            
        private CrestronString GETNEXTCOMMAND (  SplusExecutionContext __context__ ) 
            { 
            ushort MARKER1 = 0;
            
            
            __context__.SourceCodeLine = 342;
            NEXTCOMMAND  .UpdateValue ( Functions.Remove ( "\r" , COMMANDLIST )  ) ; 
            __context__.SourceCodeLine = 343;
            MARKER1 = (ushort) ( (Functions.Find( " " , NEXTCOMMAND ) - 1) ) ; 
            __context__.SourceCodeLine = 344;
            QUERY = (ushort) ( Functions.Find( "?" , NEXTCOMMAND ) ) ; 
            __context__.SourceCodeLine = 345;
            if ( Functions.TestForTrue  ( ( QUERY)  ) ) 
                { 
                __context__.SourceCodeLine = 347;
                REPLYOK  .UpdateValue ( "\u0025\u0031" + Functions.Left ( NEXTCOMMAND ,  (int) ( MARKER1 ) ) + "="  ) ; 
                } 
            
            else 
                { 
                __context__.SourceCodeLine = 351;
                REPLYOK  .UpdateValue ( "\u0025\u0031" + Functions.Left ( NEXTCOMMAND ,  (int) ( MARKER1 ) ) + "=OK\r"  ) ; 
                } 
            
            __context__.SourceCodeLine = 354;
            return ( NEXTCOMMAND ) ; 
            
            }
            
        private void SENDSECURE (  SplusExecutionContext __context__, CrestronString LRNDM__DOLLAR__ ) 
            { 
            CrestronString UNENCODED__DOLLAR__;
            CrestronString MD5ENCODED__DOLLAR__;
            UNENCODED__DOLLAR__  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 256, this );
            MD5ENCODED__DOLLAR__  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 256, this );
            
            
            __context__.SourceCodeLine = 360;
            MakeString ( UNENCODED__DOLLAR__ , "{0}{1}", LRNDM__DOLLAR__ , PJLINKPASSWORD ) ; 
            __context__.SourceCodeLine = 361;
            MakeString ( MD5ENCODED__DOLLAR__ , "{0}{1}{2}", HEX_MD5 (  __context__ , UNENCODED__DOLLAR__) , "\u0025\u0031" , GETNEXTCOMMAND (  __context__  ) ) ; 
            __context__.SourceCodeLine = 362;
            FCLIENTTX (  __context__ , MD5ENCODED__DOLLAR__) ; 
            __context__.SourceCodeLine = 363;
            CreateWait ( "WAITERSECURE" , 500 , WAITERSECURE_Callback ) ;
            
            }
            
        public void WAITERSECURE_CallbackFn( object stateInfo )
        {
        
            try
            {
                Wait __LocalWait__ = (Wait)stateInfo;
                SplusExecutionContext __context__ = SplusThreadStartCode(__LocalWait__);
                __LocalWait__.RemoveFromList();
                
            
            __context__.SourceCodeLine = 365;
            REPLYACK = (ushort) ( 1 ) ; 
            __context__.SourceCodeLine = 366;
            Trace( "No Ack received on secured transmission") ; 
            
        
        
            }
            catch(Exception e) { ObjectCatchHandler(e); }
            finally { ObjectFinallyHandler(); }
            
        }
        
    private void SENDNONSECURE (  SplusExecutionContext __context__ ) 
        { 
        CrestronString NONMD5ENCODED__DOLLAR__;
        NONMD5ENCODED__DOLLAR__  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 256, this );
        
        
        __context__.SourceCodeLine = 373;
        MakeString ( NONMD5ENCODED__DOLLAR__ , "{0}{1}", "\u0025\u0031" , GETNEXTCOMMAND (  __context__  ) ) ; 
        __context__.SourceCodeLine = 374;
        FCLIENTTX (  __context__ , NONMD5ENCODED__DOLLAR__) ; 
        
        }
        
    private void STARTPROCESSINGCOMMANDS (  SplusExecutionContext __context__ ) 
        { 
        
        __context__.SourceCodeLine = 379;
        PROCESSINGCOMMANDS = (ushort) ( 1 ) ; 
        __context__.SourceCodeLine = 380;
        while ( Functions.TestForTrue  ( ( Functions.BoolToInt ( (Functions.TestForTrue ( Functions.Length( COMMANDLIST ) ) && Functions.TestForTrue ( ISTARTCLIENT )) ))  ) ) 
            { 
            __context__.SourceCodeLine = 382;
            if ( Functions.TestForTrue  ( ( REPLYACK)  ) ) 
                { 
                __context__.SourceCodeLine = 384;
                REPLYACK = (ushort) ( 0 ) ; 
                __context__.SourceCodeLine = 385;
                SENDNONSECURE (  __context__  ) ; 
                __context__.SourceCodeLine = 386;
                CreateWait ( "WAITER" , 200 , WAITER_Callback ) ;
                } 
            
            __context__.SourceCodeLine = 392;
            Functions.Delay (  (int) ( 50 ) ) ; 
            __context__.SourceCodeLine = 380;
            } 
        
        __context__.SourceCodeLine = 394;
        PROCESSINGCOMMANDS = (ushort) ( 0 ) ; 
        
        }
        
    public void WAITER_CallbackFn( object stateInfo )
    {
    
        try
        {
            Wait __LocalWait__ = (Wait)stateInfo;
            SplusExecutionContext __context__ = SplusThreadStartCode(__LocalWait__);
            __LocalWait__.RemoveFromList();
            
            
            __context__.SourceCodeLine = 388;
            REPLYACK = (ushort) ( 1 ) ; 
            __context__.SourceCodeLine = 389;
            Trace( "No Ack received on non secured transmission") ; 
            
        
        
        }
        catch(Exception e) { ObjectCatchHandler(e); }
        finally { ObjectFinallyHandler(); }
        
    }
    
private void PROCESSQUERY (  SplusExecutionContext __context__, CrestronString FEEDBACKCOMMAND ) 
    { 
    CrestronString KEYWORD;
    KEYWORD  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 10, this );
    
    ushort MARKER1 = 0;
    ushort MARKER2 = 0;
    
    
    __context__.SourceCodeLine = 402;
    MARKER1 = (ushort) ( Functions.Find( "=" , FEEDBACKCOMMAND ) ) ; 
    __context__.SourceCodeLine = 403;
    MARKER2 = (ushort) ( Functions.Length( FEEDBACKCOMMAND ) ) ; 
    __context__.SourceCodeLine = 405;
    KEYWORD  .UpdateValue ( Functions.Left ( FEEDBACKCOMMAND ,  (int) ( MARKER1 ) )  ) ; 
    __context__.SourceCodeLine = 406;
    if ( Functions.TestForTrue  ( ( Functions.BoolToInt (KEYWORD == "%1INPT="))  ) ) 
        { 
        __context__.SourceCodeLine = 408;
        INPUTFEEDBACK__DOLLAR__  .Value = (ushort) ( Functions.Atoi( Functions.Mid( FEEDBACKCOMMAND , (int)( (MARKER1 + 1) ) , (int)( (MARKER2 - 1) ) ) ) ) ; 
        } 
    
    else 
        {
        __context__.SourceCodeLine = 410;
        if ( Functions.TestForTrue  ( ( Functions.BoolToInt (KEYWORD == "%1LAMP="))  ) ) 
            { 
            __context__.SourceCodeLine = 412;
            MARKER2 = (ushort) ( Functions.Find( " " , FEEDBACKCOMMAND ) ) ; 
            __context__.SourceCodeLine = 413;
            LAMP1HOURS__DOLLAR__  .Value = (ushort) ( Functions.Atoi( Functions.Mid( FEEDBACKCOMMAND , (int)( (MARKER1 + 1) ) , (int)( (MARKER2 - (MARKER1 + 1)) ) ) ) ) ; 
            __context__.SourceCodeLine = 414;
            LAMP1ON__DOLLAR__  .Value = (ushort) ( Functions.Atoi( Functions.Mid( FEEDBACKCOMMAND , (int)( (MARKER2 + 1) ) , (int)( 1 ) ) ) ) ; 
            __context__.SourceCodeLine = 415;
            MARKER1 = (ushort) ( Functions.Find( " " , FEEDBACKCOMMAND , (MARKER2 + 1) ) ) ; 
            __context__.SourceCodeLine = 417;
            if ( Functions.TestForTrue  ( ( MARKER1)  ) ) 
                { 
                __context__.SourceCodeLine = 419;
                MARKER2 = (ushort) ( Functions.Find( " " , FEEDBACKCOMMAND , (MARKER1 + 1) ) ) ; 
                __context__.SourceCodeLine = 420;
                LAMP2HOURS__DOLLAR__  .Value = (ushort) ( Functions.Atoi( Functions.Mid( FEEDBACKCOMMAND , (int)( MARKER2 ) , (int)( (MARKER2 - (MARKER1 + 1)) ) ) ) ) ; 
                __context__.SourceCodeLine = 421;
                LAMP2ON__DOLLAR__  .Value = (ushort) ( Functions.Atoi( Functions.Mid( FEEDBACKCOMMAND , (int)( (MARKER2 + 1) ) , (int)( 1 ) ) ) ) ; 
                } 
            
            } 
        
        else 
            {
            __context__.SourceCodeLine = 424;
            if ( Functions.TestForTrue  ( ( Functions.BoolToInt (KEYWORD == "%1ERST="))  ) ) 
                { 
                __context__.SourceCodeLine = 427;
                if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Byte( FEEDBACKCOMMAND , (int)( 8 ) ) == 49))  ) ) 
                    {
                    __context__.SourceCodeLine = 428;
                    FANWARNING__DOLLAR__  .Value = (ushort) ( 1 ) ; 
                    }
                
                else 
                    {
                    __context__.SourceCodeLine = 429;
                    if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Byte( FEEDBACKCOMMAND , (int)( 8 ) ) == 50))  ) ) 
                        {
                        __context__.SourceCodeLine = 430;
                        FANERROR__DOLLAR__  .Value = (ushort) ( 1 ) ; 
                        }
                    
                    }
                
                __context__.SourceCodeLine = 432;
                if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Byte( FEEDBACKCOMMAND , (int)( 9 ) ) == 49))  ) ) 
                    {
                    __context__.SourceCodeLine = 433;
                    LAMPWARNING__DOLLAR__  .Value = (ushort) ( 1 ) ; 
                    }
                
                else 
                    {
                    __context__.SourceCodeLine = 434;
                    if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Byte( FEEDBACKCOMMAND , (int)( 9 ) ) == 50))  ) ) 
                        {
                        __context__.SourceCodeLine = 435;
                        LAMPERROR__DOLLAR__  .Value = (ushort) ( 1 ) ; 
                        }
                    
                    }
                
                __context__.SourceCodeLine = 437;
                if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Byte( FEEDBACKCOMMAND , (int)( 10 ) ) == 49))  ) ) 
                    {
                    __context__.SourceCodeLine = 438;
                    TEMPERATUREWARNING__DOLLAR__  .Value = (ushort) ( 1 ) ; 
                    }
                
                else 
                    {
                    __context__.SourceCodeLine = 439;
                    if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Byte( FEEDBACKCOMMAND , (int)( 10 ) ) == 50))  ) ) 
                        {
                        __context__.SourceCodeLine = 440;
                        TEMPERATUREERROR__DOLLAR__  .Value = (ushort) ( 1 ) ; 
                        }
                    
                    }
                
                __context__.SourceCodeLine = 442;
                if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Byte( FEEDBACKCOMMAND , (int)( 11 ) ) == 49))  ) ) 
                    {
                    __context__.SourceCodeLine = 443;
                    COVEROPENWARNING__DOLLAR__  .Value = (ushort) ( 1 ) ; 
                    }
                
                else 
                    {
                    __context__.SourceCodeLine = 444;
                    if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Byte( FEEDBACKCOMMAND , (int)( 11 ) ) == 50))  ) ) 
                        {
                        __context__.SourceCodeLine = 445;
                        COVEROPENERROR__DOLLAR__  .Value = (ushort) ( 1 ) ; 
                        }
                    
                    }
                
                __context__.SourceCodeLine = 447;
                if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Byte( FEEDBACKCOMMAND , (int)( 12 ) ) == 49))  ) ) 
                    {
                    __context__.SourceCodeLine = 448;
                    FILTERWARNING__DOLLAR__  .Value = (ushort) ( 1 ) ; 
                    }
                
                else 
                    {
                    __context__.SourceCodeLine = 449;
                    if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Byte( FEEDBACKCOMMAND , (int)( 12 ) ) == 50))  ) ) 
                        {
                        __context__.SourceCodeLine = 450;
                        FILTERERROR__DOLLAR__  .Value = (ushort) ( 1 ) ; 
                        }
                    
                    }
                
                __context__.SourceCodeLine = 452;
                if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Byte( FEEDBACKCOMMAND , (int)( 13 ) ) == 49))  ) ) 
                    {
                    __context__.SourceCodeLine = 453;
                    OTHERWARNING__DOLLAR__  .Value = (ushort) ( 1 ) ; 
                    }
                
                else 
                    {
                    __context__.SourceCodeLine = 454;
                    if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Byte( FEEDBACKCOMMAND , (int)( 13 ) ) == 50))  ) ) 
                        {
                        __context__.SourceCodeLine = 455;
                        OTHERERROR__DOLLAR__  .Value = (ushort) ( 1 ) ; 
                        }
                    
                    }
                
                } 
            
            else 
                { 
                __context__.SourceCodeLine = 459;
                SENDTOSIMPLEWINDOWS__DOLLAR__  .UpdateValue ( FEEDBACKCOMMAND  ) ; 
                } 
            
            }
        
        }
    
    
    }
    
object COMMAND__DOLLAR___OnChange_0 ( Object __EventInfo__ )

    { 
    Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
        
        __context__.SourceCodeLine = 470;
        COMMANDLIST  .UpdateValue ( COMMANDLIST + COMMAND__DOLLAR__ + "\r"  ) ; 
        __context__.SourceCodeLine = 471;
        if ( Functions.TestForTrue  ( ( Functions.BoolToInt ( (Functions.TestForTrue ( Functions.Not( PROCESSINGCOMMANDS ) ) && Functions.TestForTrue ( Functions.BoolToInt (AOCLIENTSTATUS  .Value == 2) )) ))  ) ) 
            { 
            __context__.SourceCodeLine = 473;
            STARTPROCESSINGCOMMANDS (  __context__  ) ; 
            } 
        
        else 
            {
            __context__.SourceCodeLine = 475;
            if ( Functions.TestForTrue  ( ( Functions.BoolToInt ( (Functions.TestForTrue ( Functions.BoolToInt (AOCLIENTSTATUS  .Value != 2) ) && Functions.TestForTrue ( Functions.Not( ISTARTCLIENT ) )) ))  ) ) 
                { 
                __context__.SourceCodeLine = 477;
                FSTARTCLIENT (  __context__  ) ; 
                __context__.SourceCodeLine = 478;
                STARTPROCESSINGCOMMANDS (  __context__  ) ; 
                } 
            
            }
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SignalEventArg__ ); }
    return this;
    
}

object MYCLIENT_OnSocketConnect_1 ( Object __Info__ )

    { 
    SocketEventInfo __SocketInfo__ = (SocketEventInfo)__Info__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SocketInfo__);
        int PORTNUMBER = 0;
        
        short LOCALSTATUS = 0;
        
        CrestronString REMOTEIPADDRESS;
        REMOTEIPADDRESS  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 20, this );
        
        CrestronString REQUESTEDADDRESS;
        REQUESTEDADDRESS  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 256, this );
        
        
        __context__.SourceCodeLine = 489;
        DOCLIENTCONNECTED  .Value = (ushort) ( 1 ) ; 
        __context__.SourceCodeLine = 490;
        LOCALSTATUS = (short) ( Functions.SocketGetAddressAsRequested( MYCLIENT , ref REQUESTEDADDRESS ) ) ; 
        __context__.SourceCodeLine = 491;
        if ( Functions.TestForTrue  ( ( Functions.BoolToInt ( LOCALSTATUS < 0 ))  ) ) 
            {
            __context__.SourceCodeLine = 492;
            Trace( "Client: Error getting remote ip address. {0:d}\r\n", (short)LOCALSTATUS) ; 
            }
        
        __context__.SourceCodeLine = 494;
        PORTNUMBER = (int) ( Functions.SocketGetPortNumber( MYCLIENT ) ) ; 
        __context__.SourceCodeLine = 495;
        if ( Functions.TestForTrue  ( ( Functions.BoolToInt ( PORTNUMBER < 0 ))  ) ) 
            {
            __context__.SourceCodeLine = 496;
            Trace( "Client: Error getting client port number. {0:d}\r\n", (int)PORTNUMBER) ; 
            }
        
        __context__.SourceCodeLine = 498;
        LOCALSTATUS = (short) ( Functions.SocketGetRemoteIPAddress( MYCLIENT , ref REMOTEIPADDRESS ) ) ; 
        __context__.SourceCodeLine = 499;
        if ( Functions.TestForTrue  ( ( Functions.BoolToInt ( LOCALSTATUS < 0 ))  ) ) 
            {
            __context__.SourceCodeLine = 500;
            Trace( "Client: Error getting remote ip address. {0:d}\r\n", (short)LOCALSTATUS) ; 
            }
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SocketInfo__ ); }
    return this;
    
}

object MYCLIENT_OnSocketDisconnect_2 ( Object __Info__ )

    { 
    SocketEventInfo __SocketInfo__ = (SocketEventInfo)__Info__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SocketInfo__);
        
        __context__.SourceCodeLine = 505;
        REPLYACK = (ushort) ( 0 ) ; 
        __context__.SourceCodeLine = 506;
        DOCLIENTCONNECTED  .Value = (ushort) ( 0 ) ; 
        __context__.SourceCodeLine = 507;
        if ( Functions.TestForTrue  ( ( ISTARTCLIENT)  ) ) 
            { 
            __context__.SourceCodeLine = 509;
            Trace( "Client: Socket disconnected remotely") ; 
            __context__.SourceCodeLine = 510;
            ISTARTCLIENT = (ushort) ( 0 ) ; 
            } 
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SocketInfo__ ); }
    return this;
    
}

object MYCLIENT_OnSocketStatus_3 ( Object __Info__ )

    { 
    SocketEventInfo __SocketInfo__ = (SocketEventInfo)__Info__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SocketInfo__);
        short STATUS = 0;
        
        
        __context__.SourceCodeLine = 518;
        STATUS = (short) ( __SocketInfo__.SocketStatus ) ; 
        __context__.SourceCodeLine = 519;
        if ( Functions.TestForTrue  ( ( Functions.BoolToInt (STATUS == 2))  ) ) 
            { 
            __context__.SourceCodeLine = 521;
            CreateWait ( "AUTODISCONNECT" , 1000 , AUTODISCONNECT_Callback ) ;
            } 
        
        else 
            { 
            __context__.SourceCodeLine = 528;
            CancelWait ( "AUTODISCONNECT" ) ; 
            } 
        
        __context__.SourceCodeLine = 530;
        AOCLIENTSTATUS  .Value = (ushort) ( STATUS ) ; 
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SocketInfo__ ); }
    return this;
    
}

public void AUTODISCONNECT_CallbackFn( object stateInfo )
{

    try
    {
        Wait __LocalWait__ = (Wait)stateInfo;
        SplusExecutionContext __context__ = SplusThreadStartCode(__LocalWait__);
        __LocalWait__.RemoveFromList();
        
            
            __context__.SourceCodeLine = 523;
            FSTOPCLIENT (  __context__  ) ; 
            
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler(); }
    
}

object MYCLIENT_OnSocketReceive_4 ( Object __Info__ )

    { 
    SocketEventInfo __SocketInfo__ = (SocketEventInfo)__Info__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SocketInfo__);
        ushort REPLYERRLEN = 0;
        ushort REPLYVALUELEN = 0;
        
        
        __context__.SourceCodeLine = 536;
        if ( Functions.TestForTrue  ( ( RXOK)  ) ) 
            { 
            __context__.SourceCodeLine = 538;
            RXOK = (ushort) ( 0 ) ; 
            __context__.SourceCodeLine = 539;
            while ( Functions.TestForTrue  ( ( Functions.BoolToInt ( Functions.Find( "\u000D" , MYCLIENT.SocketRxBuf ) > 0 ))  ) ) 
                { 
                __context__.SourceCodeLine = 541;
                RXCOMMAND  .UpdateValue ( Functions.Remove ( "\u000D" , MYCLIENT .  SocketRxBuf )  ) ; 
                __context__.SourceCodeLine = 542;
                while ( Functions.TestForTrue  ( ( Functions.Length( RXCOMMAND ))  ) ) 
                    { 
                    __context__.SourceCodeLine = 544;
                    if ( Functions.TestForTrue  ( ( Functions.BoolToInt ( (Functions.TestForTrue ( Functions.BoolToInt (Functions.Left( RXCOMMAND , (int)( 1 ) ) == "%") ) || Functions.TestForTrue ( Functions.BoolToInt (Functions.Left( RXCOMMAND , (int)( 6 ) ) == "PJLINK") )) ))  ) ) 
                        { 
                        __context__.SourceCodeLine = 546;
                        if ( Functions.TestForTrue  ( ( Functions.Find( "ERR" , RXCOMMAND ))  ) ) 
                            { 
                            __context__.SourceCodeLine = 548;
                            CancelWait ( "WAITERSECURE" ) ; 
                            __context__.SourceCodeLine = 549;
                            CancelWait ( "WAITER" ) ; 
                            __context__.SourceCodeLine = 550;
                            REPLYACK = (ushort) ( 1 ) ; 
                            __context__.SourceCodeLine = 551;
                            Trace( "Command not supported or Unit is turned Off") ; 
                            } 
                        
                        else 
                            {
                            __context__.SourceCodeLine = 553;
                            if ( Functions.TestForTrue  ( ( Functions.BoolToInt (RXCOMMAND == REPLYOK))  ) ) 
                                { 
                                __context__.SourceCodeLine = 555;
                                CancelWait ( "WAITER" ) ; 
                                __context__.SourceCodeLine = 556;
                                CancelWait ( "WAITERSECURE" ) ; 
                                __context__.SourceCodeLine = 557;
                                REPLYACK = (ushort) ( 1 ) ; 
                                } 
                            
                            else 
                                {
                                __context__.SourceCodeLine = 559;
                                if ( Functions.TestForTrue  ( ( Functions.BoolToInt ( (Functions.TestForTrue ( Functions.BoolToInt (Functions.Left( RXCOMMAND , (int)( Functions.Length( REPLYOK ) ) ) == REPLYOK) ) && Functions.TestForTrue ( QUERY )) ))  ) ) 
                                    { 
                                    __context__.SourceCodeLine = 561;
                                    PROCESSQUERY (  __context__ , RXCOMMAND) ; 
                                    __context__.SourceCodeLine = 562;
                                    CancelWait ( "WAITER" ) ; 
                                    __context__.SourceCodeLine = 563;
                                    REPLYACK = (ushort) ( 1 ) ; 
                                    } 
                                
                                else 
                                    {
                                    __context__.SourceCodeLine = 565;
                                    if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Functions.Left( RXCOMMAND , (int)( 8 ) ) == "PJLINK 1"))  ) ) 
                                        { 
                                        __context__.SourceCodeLine = 567;
                                        RNDM__DOLLAR__  .UpdateValue ( Functions.Mid ( RXCOMMAND ,  (int) ( 10 ) ,  (int) ( (Functions.Length( RXCOMMAND ) - 10) ) )  ) ; 
                                        __context__.SourceCodeLine = 568;
                                        SENDSECURE (  __context__ , RNDM__DOLLAR__) ; 
                                        } 
                                    
                                    else 
                                        {
                                        __context__.SourceCodeLine = 570;
                                        if ( Functions.TestForTrue  ( ( Functions.BoolToInt (Functions.Left( RXCOMMAND , (int)( 8 ) ) == "PJLINK 0"))  ) ) 
                                            { 
                                            __context__.SourceCodeLine = 572;
                                            SENDNONSECURE (  __context__  ) ; 
                                            } 
                                        
                                        else 
                                            {
                                            __context__.SourceCodeLine = 574;
                                            if ( Functions.TestForTrue  ( ( Functions.BoolToInt (RXCOMMAND == "PJLINK ERRA\u000D"))  ) ) 
                                                { 
                                                __context__.SourceCodeLine = 576;
                                                Trace( "error in authentication") ; 
                                                } 
                                            
                                            }
                                        
                                        }
                                    
                                    }
                                
                                }
                            
                            }
                        
                        __context__.SourceCodeLine = 579;
                        RetimeWait ( (int)1000, "AUTODISCONNECT" ) ; 
                        __context__.SourceCodeLine = 580;
                        Functions.ClearBuffer ( RXCOMMAND ) ; 
                        } 
                    
                    else 
                        { 
                        __context__.SourceCodeLine = 584;
                        HELPRX = (ushort) ( Functions.GetC( RXCOMMAND ) ) ; 
                        } 
                    
                    __context__.SourceCodeLine = 542;
                    } 
                
                __context__.SourceCodeLine = 539;
                } 
            
            __context__.SourceCodeLine = 588;
            RXOK = (ushort) ( 1 ) ; 
            } 
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SocketInfo__ ); }
    return this;
    
}

public override object FunctionMain (  object __obj__ ) 
    { 
    try
    {
        SplusExecutionContext __context__ = SplusFunctionMainStartCode();
        
        __context__.SourceCodeLine = 601;
        CHRSZ = (int) ( 8 ) ; 
        __context__.SourceCodeLine = 602;
        RXOK = (ushort) ( 1 ) ; 
        __context__.SourceCodeLine = 603;
        PROCESSINGCOMMANDS = (ushort) ( 0 ) ; 
        __context__.SourceCodeLine = 604;
        QUERY = (ushort) ( 0 ) ; 
        __context__.SourceCodeLine = 605;
        REPLYACK = (ushort) ( 0 ) ; 
        __context__.SourceCodeLine = 607;
        HEX_TAB [ 0] = (ushort) ( 48 ) ; 
        __context__.SourceCodeLine = 608;
        HEX_TAB [ 1] = (ushort) ( 49 ) ; 
        __context__.SourceCodeLine = 609;
        HEX_TAB [ 2] = (ushort) ( 50 ) ; 
        __context__.SourceCodeLine = 610;
        HEX_TAB [ 3] = (ushort) ( 51 ) ; 
        __context__.SourceCodeLine = 611;
        HEX_TAB [ 4] = (ushort) ( 52 ) ; 
        __context__.SourceCodeLine = 612;
        HEX_TAB [ 5] = (ushort) ( 53 ) ; 
        __context__.SourceCodeLine = 613;
        HEX_TAB [ 6] = (ushort) ( 54 ) ; 
        __context__.SourceCodeLine = 614;
        HEX_TAB [ 7] = (ushort) ( 55 ) ; 
        __context__.SourceCodeLine = 615;
        HEX_TAB [ 8] = (ushort) ( 56 ) ; 
        __context__.SourceCodeLine = 616;
        HEX_TAB [ 9] = (ushort) ( 57 ) ; 
        __context__.SourceCodeLine = 617;
        HEX_TAB [ 10] = (ushort) ( 97 ) ; 
        __context__.SourceCodeLine = 618;
        HEX_TAB [ 11] = (ushort) ( 98 ) ; 
        __context__.SourceCodeLine = 619;
        HEX_TAB [ 12] = (ushort) ( 99 ) ; 
        __context__.SourceCodeLine = 620;
        HEX_TAB [ 13] = (ushort) ( 100 ) ; 
        __context__.SourceCodeLine = 621;
        HEX_TAB [ 14] = (ushort) ( 101 ) ; 
        __context__.SourceCodeLine = 622;
        HEX_TAB [ 15] = (ushort) ( 102 ) ; 
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler(); }
    return __obj__;
    }
    

public override void LogosSplusInitialize()
{
    SocketInfo __socketinfo__ = new SocketInfo( 1, this );
    InitialParametersClass.ResolveHostName = __socketinfo__.ResolveHostName;
    _SplusNVRAM = new SplusNVRAM( this );
    HEX_TAB  = new ushort[ 17 ];
    BIN  = new int[ 2001 ];
    BINARRAY  = new int[ 5 ];
    SCLIENTRX__DOLLAR__  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 256, this );
    COMMANDVALUE__DOLLAR__  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 256, this );
    REPLYERR__DOLLAR__  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 256, this );
    REPLYVALUE__DOLLAR__  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 256, this );
    RNDM__DOLLAR__  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 256, this );
    COMMANDLIST  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 512, this );
    RXCOMMAND  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 512, this );
    NEXTCOMMAND  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 256, this );
    REPLYOK  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 256, this );
    MYCLIENT  = new SplusTcpClient ( 1024, this );
    
    DOCLIENTCONNECTED = new Crestron.Logos.SplusObjects.DigitalOutput( DOCLIENTCONNECTED__DigitalOutput__, this );
    m_DigitalOutputList.Add( DOCLIENTCONNECTED__DigitalOutput__, DOCLIENTCONNECTED );
    
    LAMP1ON__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( LAMP1ON__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( LAMP1ON__DOLLAR____DigitalOutput__, LAMP1ON__DOLLAR__ );
    
    LAMP2ON__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( LAMP2ON__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( LAMP2ON__DOLLAR____DigitalOutput__, LAMP2ON__DOLLAR__ );
    
    FANWARNING__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( FANWARNING__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( FANWARNING__DOLLAR____DigitalOutput__, FANWARNING__DOLLAR__ );
    
    FANERROR__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( FANERROR__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( FANERROR__DOLLAR____DigitalOutput__, FANERROR__DOLLAR__ );
    
    LAMPWARNING__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( LAMPWARNING__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( LAMPWARNING__DOLLAR____DigitalOutput__, LAMPWARNING__DOLLAR__ );
    
    LAMPERROR__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( LAMPERROR__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( LAMPERROR__DOLLAR____DigitalOutput__, LAMPERROR__DOLLAR__ );
    
    TEMPERATUREWARNING__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( TEMPERATUREWARNING__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( TEMPERATUREWARNING__DOLLAR____DigitalOutput__, TEMPERATUREWARNING__DOLLAR__ );
    
    TEMPERATUREERROR__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( TEMPERATUREERROR__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( TEMPERATUREERROR__DOLLAR____DigitalOutput__, TEMPERATUREERROR__DOLLAR__ );
    
    COVEROPENWARNING__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( COVEROPENWARNING__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( COVEROPENWARNING__DOLLAR____DigitalOutput__, COVEROPENWARNING__DOLLAR__ );
    
    COVEROPENERROR__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( COVEROPENERROR__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( COVEROPENERROR__DOLLAR____DigitalOutput__, COVEROPENERROR__DOLLAR__ );
    
    FILTERWARNING__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( FILTERWARNING__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( FILTERWARNING__DOLLAR____DigitalOutput__, FILTERWARNING__DOLLAR__ );
    
    FILTERERROR__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( FILTERERROR__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( FILTERERROR__DOLLAR____DigitalOutput__, FILTERERROR__DOLLAR__ );
    
    OTHERWARNING__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( OTHERWARNING__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( OTHERWARNING__DOLLAR____DigitalOutput__, OTHERWARNING__DOLLAR__ );
    
    OTHERERROR__DOLLAR__ = new Crestron.Logos.SplusObjects.DigitalOutput( OTHERERROR__DOLLAR____DigitalOutput__, this );
    m_DigitalOutputList.Add( OTHERERROR__DOLLAR____DigitalOutput__, OTHERERROR__DOLLAR__ );
    
    AOCLIENTSTATUS = new Crestron.Logos.SplusObjects.AnalogOutput( AOCLIENTSTATUS__AnalogSerialOutput__, this );
    m_AnalogOutputList.Add( AOCLIENTSTATUS__AnalogSerialOutput__, AOCLIENTSTATUS );
    
    INPUTFEEDBACK__DOLLAR__ = new Crestron.Logos.SplusObjects.AnalogOutput( INPUTFEEDBACK__DOLLAR____AnalogSerialOutput__, this );
    m_AnalogOutputList.Add( INPUTFEEDBACK__DOLLAR____AnalogSerialOutput__, INPUTFEEDBACK__DOLLAR__ );
    
    LAMP1HOURS__DOLLAR__ = new Crestron.Logos.SplusObjects.AnalogOutput( LAMP1HOURS__DOLLAR____AnalogSerialOutput__, this );
    m_AnalogOutputList.Add( LAMP1HOURS__DOLLAR____AnalogSerialOutput__, LAMP1HOURS__DOLLAR__ );
    
    LAMP2HOURS__DOLLAR__ = new Crestron.Logos.SplusObjects.AnalogOutput( LAMP2HOURS__DOLLAR____AnalogSerialOutput__, this );
    m_AnalogOutputList.Add( LAMP2HOURS__DOLLAR____AnalogSerialOutput__, LAMP2HOURS__DOLLAR__ );
    
    COMMAND__DOLLAR__ = new Crestron.Logos.SplusObjects.StringInput( COMMAND__DOLLAR____AnalogSerialInput__, 15, this );
    m_StringInputList.Add( COMMAND__DOLLAR____AnalogSerialInput__, COMMAND__DOLLAR__ );
    
    SENDTOSIMPLEWINDOWS__DOLLAR__ = new Crestron.Logos.SplusObjects.StringOutput( SENDTOSIMPLEWINDOWS__DOLLAR____AnalogSerialOutput__, this );
    m_StringOutputList.Add( SENDTOSIMPLEWINDOWS__DOLLAR____AnalogSerialOutput__, SENDTOSIMPLEWINDOWS__DOLLAR__ );
    
    PROJECTOR_TCPIP_PORTNUMBER = new UShortParameter( PROJECTOR_TCPIP_PORTNUMBER__Parameter__, this );
    m_ParameterList.Add( PROJECTOR_TCPIP_PORTNUMBER__Parameter__, PROJECTOR_TCPIP_PORTNUMBER );
    
    PROJECTOR_IP_ADDRESS = new StringParameter( PROJECTOR_IP_ADDRESS__Parameter__, this );
    m_ParameterList.Add( PROJECTOR_IP_ADDRESS__Parameter__, PROJECTOR_IP_ADDRESS );
    
    PJLINKPASSWORD = new StringParameter( PJLINKPASSWORD__Parameter__, this );
    m_ParameterList.Add( PJLINKPASSWORD__Parameter__, PJLINKPASSWORD );
    
    WAITERSECURE_Callback = new WaitFunction( WAITERSECURE_CallbackFn );
    WAITER_Callback = new WaitFunction( WAITER_CallbackFn );
    AUTODISCONNECT_Callback = new WaitFunction( AUTODISCONNECT_CallbackFn );
    
    COMMAND__DOLLAR__.OnSerialChange.Add( new InputChangeHandlerWrapper( COMMAND__DOLLAR___OnChange_0, false ) );
    MYCLIENT.OnSocketConnect.Add( new SocketHandlerWrapper( MYCLIENT_OnSocketConnect_1, false ) );
    MYCLIENT.OnSocketDisconnect.Add( new SocketHandlerWrapper( MYCLIENT_OnSocketDisconnect_2, false ) );
    MYCLIENT.OnSocketStatus.Add( new SocketHandlerWrapper( MYCLIENT_OnSocketStatus_3, false ) );
    MYCLIENT.OnSocketReceive.Add( new SocketHandlerWrapper( MYCLIENT_OnSocketReceive_4, false ) );
    
    _SplusNVRAM.PopulateCustomAttributeList( true );
    
    NVRAM = _SplusNVRAM;
    
}

public override void LogosSimplSharpInitialize()
{
    
    
}

public UserModuleClass_PJLINK ( string InstanceName, string ReferenceID, Crestron.Logos.SplusObjects.CrestronStringEncoding nEncodingType ) : base( InstanceName, ReferenceID, nEncodingType ) {}


private WaitFunction WAITERSECURE_Callback;
private WaitFunction WAITER_Callback;
private WaitFunction AUTODISCONNECT_Callback;


const uint COMMAND__DOLLAR____AnalogSerialInput__ = 0;
const uint DOCLIENTCONNECTED__DigitalOutput__ = 0;
const uint LAMP1ON__DOLLAR____DigitalOutput__ = 1;
const uint LAMP2ON__DOLLAR____DigitalOutput__ = 2;
const uint FANWARNING__DOLLAR____DigitalOutput__ = 3;
const uint FANERROR__DOLLAR____DigitalOutput__ = 4;
const uint LAMPWARNING__DOLLAR____DigitalOutput__ = 5;
const uint LAMPERROR__DOLLAR____DigitalOutput__ = 6;
const uint TEMPERATUREWARNING__DOLLAR____DigitalOutput__ = 7;
const uint TEMPERATUREERROR__DOLLAR____DigitalOutput__ = 8;
const uint COVEROPENWARNING__DOLLAR____DigitalOutput__ = 9;
const uint COVEROPENERROR__DOLLAR____DigitalOutput__ = 10;
const uint FILTERWARNING__DOLLAR____DigitalOutput__ = 11;
const uint FILTERERROR__DOLLAR____DigitalOutput__ = 12;
const uint OTHERWARNING__DOLLAR____DigitalOutput__ = 13;
const uint OTHERERROR__DOLLAR____DigitalOutput__ = 14;
const uint AOCLIENTSTATUS__AnalogSerialOutput__ = 0;
const uint INPUTFEEDBACK__DOLLAR____AnalogSerialOutput__ = 1;
const uint LAMP1HOURS__DOLLAR____AnalogSerialOutput__ = 2;
const uint LAMP2HOURS__DOLLAR____AnalogSerialOutput__ = 3;
const uint SENDTOSIMPLEWINDOWS__DOLLAR____AnalogSerialOutput__ = 4;
const uint PROJECTOR_TCPIP_PORTNUMBER__Parameter__ = 10;
const uint PROJECTOR_IP_ADDRESS__Parameter__ = 11;
const uint PJLINKPASSWORD__Parameter__ = 12;

[SplusStructAttribute(-1, true, false)]
public class SplusNVRAM : SplusStructureBase
{

    public SplusNVRAM( SplusObject __caller__ ) : base( __caller__ ) {}
    
    
}

SplusNVRAM _SplusNVRAM = null;

public class __CEvent__ : CEvent
{
    public __CEvent__() {}
    public void Close() { base.Close(); }
    public int Reset() { return base.Reset() ? 1 : 0; }
    public int Set() { return base.Set() ? 1 : 0; }
    public int Wait( int timeOutInMs ) { return base.Wait( timeOutInMs ) ? 1 : 0; }
}
public class __CMutex__ : CMutex
{
    public __CMutex__() {}
    public void Close() { base.Close(); }
    public void ReleaseMutex() { base.ReleaseMutex(); }
    public int WaitForMutex() { return base.WaitForMutex() ? 1 : 0; }
}
 public int IsNull( object obj ){ return (obj == null) ? 1 : 0; }
}


}
